---@meta

---A marker pack texture.
---@class Texture
---@field Height integer # The height of the texture.
---@field Width integer # The width of the texture.
local Texture = {}